exports.resetEmail = (host, resetToken) => {
  const message = {
    subject: 'Reset Password',
    text:
      `${
        'You are receiving this because you have requested to reset your password for your account.\n\n' +
        'Please click on the following link, or paste this into your browser to complete the process:\n\n' +
        'http://'
      }${host}/reset-password/${resetToken}\n\n` +
      `If you did not request this, please ignore this email and your password will remain unchanged.\n`
  };

  return message;
};

exports.confirmResetPasswordEmail = () => {
  const message = {
    subject: 'Password Changed',
    text:
      `You are receiving this email because you changed your password. \n\n` +
      `If you did not request this change, please contact us immediately.`
  };

  return message;
};

exports.signupEmail = (name) => {
  const message = {
    subject: 'Account Registration',
    text: `Hi ${name.username} Thank you for creating an account with us!.`
  };

  return message;
};
exports.questionPosted = () => {
  const message = {
    subject: 'Question Posted on TakeCode',
    text: `We received your request! Our team will contact you soon. \n\n`
  };

  return message;
};
exports.questionApproved = name => {
  const message = {
    subject: 'Question Approved',
    text:
      `Hi ${name}! Congratulations! Your Question has been accepted. \n\n` +
      ` Please see your question on takecode and you will be able to see answer of your respective question.`
  };

  return message;
};