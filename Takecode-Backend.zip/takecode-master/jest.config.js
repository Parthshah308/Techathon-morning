module.exports = {
    setupFilesAfterEnv: ['./test/setup.js'],
    testEnvironment: 'node'
  };